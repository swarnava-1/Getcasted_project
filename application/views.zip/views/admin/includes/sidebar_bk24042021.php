 <div class="left side-menu" style="background:#3fb6e4;">
                <div class="sidebar-inner slimscrollleft">
                    <div class="user-details">
                        <div class="pull-left">
                            <img src="<?php echo base_url();?>assets2/assets/admin2/images/users/avatar-1.jpg" alt="" class="thumb-md img-circle">
                        </div>
                        <div class="user-info">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Admin <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo base_url();?>profile"><i class="md md-face-unlock"></i> Profile<div class="ripple-wrapper"></div></a></li>
                                    <li><a href="<?php echo base_url();?>login/signOut"><i class="md md-settings-power"></i> Logout</a></li>
                                </ul>
                            </div>
                            
                            <h5 style="color:white;" class="text-muted m-0"></h5>
                        </div>
                    </div>
                    <!--- Divider -->
                    <div id="sidebar-menu" style="background:#3fb6e4;">
                        <ul>
                            <li>
                                <a href="<?php echo base_url();?>index" class="waves-effect"><i class="md md-home"></i><span><b>Dashboard</b> </span></a>
                            </li>
                          
                            <li class="active treeview">
                                <a href="<?php echo base_url();?>contacts">
                                    <i class="fa fa-fw fa-users"></i>
                                    <span>Contacts Management</span>
                                </a>
                            </li>
                             
                            <li class="active treeview">
                                <a href="<?php echo base_url();?>accounts">
                                    <i class="fa fa-fw fa-users"></i>
                                    <span>Accounts Management</span>
                                </a>
                            </li>
                            
                           
                            
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>