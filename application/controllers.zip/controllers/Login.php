<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct() {

        parent::__construct();

        $this->load->library('session');
        $this->session;
        $this->load->helper('url');
        $this->load->model('login_model');
        //$this->load->model('user_model');

	/*	$this->load->model('about_us_model');
        $this->load->model('sitesetting_model');
		$this->load->model('header_model');

        //if(!$this->session->userdata('is_logged_in')) {
            //redirect('admin/login');
        }*/ 
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index() {
		$this->load->view('login');
	}
	public function validate() { 
		
		$email = $this->input->post('email');
		$password = $this->input->post('password');


		$flag = $this->login_model->check_login($email, $password);
		//echo $flag;
		//echo '<pre>';print_r($flag);die;
		if(sizeof($flag) > 0) {
			if($flag[0]->id > 0) {
				$this->session->set_userdata('user_id', $flag[0]->id);
				$this->session->set_userdata('email', $flag[0]->email);
				$this->session->set_userdata('user_name', $flag[0]->company_name_or_individual_name);
				$this->session->set_userdata('role_id', $flag[0]->role_id);
				$this->session->set_userdata('err_msg','');
				if($flag[0]->role_id == "1"){
					redirect(base_url().'admin/index');
				}elseif($flag[0]->role_id == "2"){
					redirect(base_url().'castingDirector/director/project_list');
				}elseif($flag[0]->role_id == "3"){
					redirect(base_url().'agents/agent/project_list');
				}elseif($flag[0]->role_id == "4"){
					redirect(base_url().'talent/talent_details/project_list');
				}
			}
			else {

				$this->session->set_userdata('err_msg','* Invalid Email or Password !');
				redirect(base_url().'login');
			}
		}
		else {

			$this->session->set_userdata('err_msg','* Invalid Email or Password !');
			redirect(base_url().'login');
		}
		//redirect(base_url().'index');
	}
			
		
}