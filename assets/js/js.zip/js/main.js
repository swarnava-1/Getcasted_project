$(document).ready(function(){	
	$('.drpdnMnu').click(function(){
		//alert();
		$('.mnu-mn').slideToggle('slow');
	});
});